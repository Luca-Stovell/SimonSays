#include <avr/io.h>

#include "initialisation.h"


void led_init(void)
{
    PORTB.OUTSET = PIN1_bm; // LED off initially
    PORTB.DIRSET = PIN1_bm; // Enable PB1 as output
}

void potentionmeter_init(void){
    PORTA.DIRCLR = (1 << 2);  // Makes PA2 an input pin
}

void adc_init(){
    ADC0.CTRLA = ADC_ENABLE_bm;

    ADC0.CTRLB = ADC_PRESC_DIV2_gc;

    ADC0.CTRLC = (4 << ADC_TIMEBASE_gp) | ADC_REFSEL_VDD_gc;

    ADC0.CTRLE = 64;

    ADC0.CTRLF = ADC_FREERUN_bm;

    ADC0.MUXPOS = ADC_MUXPOS_AIN2_gc;

    ADC0.COMMAND = ADC_MODE_SINGLE_8BIT_gc | ADC_START_IMMEDIATE_gc;
}
