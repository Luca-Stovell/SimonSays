#include <avr/io.h>
#include "display_macros.h"

#include <avr/interrupt.h>

volatile uint8_t digit_l = DISP_OFF;
volatile uint8_t digit_r = DISP_OFF;

void display_init(void) {
    PORTMUX.SPIROUTEA = PORTMUX_SPI0_ALT1_gc;  // SPI pins on PC0-3

    // SPI SCK and MOSI
    PORTC.DIRSET = (PIN0_bm | PIN2_bm);   // SCK (PC0) and MOSI (PC2) output

    // DISP_LATCH
    PORTA.OUTSET = PIN1_bm;        // DISP_LATCH initial high
    PORTA.DIRSET = PIN1_bm;        // set DISP_LATCH pin as output

    SPI0.CTRLA = SPI_MASTER_bm;    // Master, /4 prescaler, MSB first
    SPI0.CTRLB = SPI_SSD_bm;       // Mode 0, client select disable, unbuffered
    SPI0.INTCTRL = SPI_IE_bm;      // Interrupt enable
    SPI0.CTRLA |= SPI_ENABLE_bm;   // Enable
}

// Set the display segments (this replaces set_display_segments)
void set_display_segments(uint8_t segs_l, uint8_t segs_r) {
    digit_l = segs_l;
    digit_r = segs_r;
}

// Timer-driven multiplexing: swap digits
void swap_display_digit(void) {
    static int digit = 0;
    
    if (digit) {
        SPI0.DATA = digit_l | (1 << 7);  // Left digit: set DISP_LHS bit
    } else {
        SPI0.DATA = digit_r;             // Right digit: DISP_LHS not set
    }
    digit = !digit;
}

void display_off(void)
{
    set_display_segments(DISP_OFF, DISP_OFF);
}

void display_pattern_1(){
    set_display_segments(DISP_BAR_LEFT, DISP_OFF);
}

void display_pattern_2(){
    set_display_segments(DISP_BAR_RIGHT, DISP_OFF);
}

void display_pattern_3(){
    set_display_segments(DISP_OFF, DISP_BAR_LEFT);
}

void display_pattern_4(){
    set_display_segments(DISP_OFF, DISP_BAR_RIGHT);
}

void display_success_pattern(){
    set_display_segments(DISP_ON, DISP_ON);
}

void display_fail_pattern(){
    set_display_segments(DISP_SEG_G, DISP_SEG_G);
}

ISR(SPI0_INT_vect) {
    PORTA.OUTCLR = PIN1_bm;
    PORTA.OUTSET = PIN1_bm;
    SPI0.INTFLAGS = SPI_IF_bm;
}
