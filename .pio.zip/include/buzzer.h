#ifndef BUZZER_H
#define BUZZER_H

#include <stdint.h>

void buzzer_init(void);
void play_tone(uint8_t button);  // <-- Add this
void stop_tone(void);

#endif